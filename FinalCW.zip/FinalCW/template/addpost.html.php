<form action="" method="post">
    <label for='posttext'> type your post here;</label>
    <textarea name="posttext" rows="3" cols="40"></textarea>
    <label for='file'> choose image;</label>
    <input type="file" name="fileToUpload">


    <select name="users">
        <option value="">Seclect an user</option>
        <?php foreach ($users as $user):?>

            <option value="<?=htmlspecialchars($user['id'], ENT_QUOTES,'UTF-8');?>">
            <?=htmlspecialchars($user['name'],ENT_QUOTES,'UTF-8');?>               
            </option>
            <?php endforeach;?>
        
    </select>

    <select name="modules">
        <option value="">select a module</option>
        <?php foreach ($modules as $module):?>
            
            <option value="<?=htmlspecialchars($module['id'], ENT_QUOTES,'UTF-8');?>">
            <?=htmlspecialchars($module['ModuleName'],ENT_QUOTES,'UTF-8');?>               
            </option>
            <?php endforeach;?>
    </select>

    <input type="submit" name="submit" value="add">
</form>