package com.example.calculatorapplication // SỬA: Đổi về đúng package gốc của dự án

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
// SỬA: Import đúng đường dẫn theme.
// Nếu IDE báo đỏ dòng này, hãy xóa dòng import này đi và để Android Studio tự gợi ý (Alt+Enter)
import com.example.calculatorapplication.ui.theme.CalculatorApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // SỬA: Tên Theme thường trùng với tên Project, bỏ số '2' nếu project tên là CalculatorApplication
            CalculatorApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CalculatorScreen()
                }
            }
        }
    }
}

@Composable
fun CalculatorScreen() {
    val context = LocalContext.current

    // Biến trạng thái (State) cho input và kết quả
    var operand1 by remember { mutableStateOf("") }
    var operand2 by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }

    // Lấy chuỗi từ resource
    // LƯU Ý: Nếu R báo đỏ, hãy thử Build -> Clean Project sau đó Rebuild Project
    val errorEmpty = stringResource(R.string.error_empty)
    val errorDivZero = stringResource(R.string.error_div_zero)

    // Hàm hỗ trợ tính toán
    fun calculate(operation: (Double, Double) -> Double) {
        if (operand1.isEmpty() || operand2.isEmpty()) {
            Toast.makeText(context, errorEmpty, Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val num1 = operand1.toDouble()
            val num2 = operand2.toDouble()
            val res = operation(num1, num2)
            result = "Result: $res"
        } catch (e: NumberFormatException) {
            Toast.makeText(context, "Invalid number format", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.calc_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Input 1
        OutlinedTextField(
            value = operand1,
            onValueChange = { operand1 = it },
            label = { Text(stringResource(R.string.operand_1)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Input 2
        OutlinedTextField(
            value = operand2,
            onValueChange = { operand2 = it },
            label = { Text(stringResource(R.string.operand_2)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Hàng chứa các nút bấm
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { calculate { a, b -> a + b } }) { Text("+") }
            Button(onClick = { calculate { a, b -> a - b } }) { Text("-") }
            Button(onClick = { calculate { a, b -> a * b } }) { Text("*") }
            Button(onClick = {
                if (operand2.toDoubleOrNull() == 0.0) {
                    Toast.makeText(context, errorDivZero, Toast.LENGTH_SHORT).show()
                } else {
                    calculate { a, b -> a / b }
                }
            }) { Text("/") }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Hiển thị kết quả
        if (result != null) {
            Text(
                text = result!!,
                style = MaterialTheme.typography.headlineSmall,
                fontSize = 24.sp
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    CalculatorApplicationTheme {
        CalculatorScreen()
    }
}
